package com.example.miniproject;

public class DatabaseReference {
    public Object child;
}
